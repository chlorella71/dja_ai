import React from 'react';

const Region = () => {
  return (
    <div>
      Region
    </div>
  );
}

export default Region;
