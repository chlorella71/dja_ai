import React from 'react';

const DatePage = () => {
  return (
    <div>
      DataPage
    </div>
  );
}

export default DatePage;
