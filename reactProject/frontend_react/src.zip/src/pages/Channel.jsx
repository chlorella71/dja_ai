import React from 'react';

const Channel = () => {
  return (
    <div>
      Channel
    </div>
  );
}

export default Channel;
